"use strict";

// Prevent double initialization (VERY IMPORTANT)
if (window.__kt_signup_initialized) {
    console.warn('Signup JS already initialized');
} else {

    window.__kt_signup_initialized = true;

    var KTSignupGeneral = function () {

        var form;
        var submitButton;
        var validator;
        var passwordMeter;

        var validatePassword = function () {
            return passwordMeter.getScore() > 50;
        };

        var handleFormAjax = function () {

            // 🔐 Prevent double submit handler
            if (form.dataset.submitBound === "1") {
                return;
            }
            form.dataset.submitBound = "1";

            validator = FormValidation.formValidation(
                form,
                {
                    fields: {
                        name: {
                            validators: {
                                notEmpty: { message: 'Name is required' }
                            }
                        },
                        email: {
                            validators: {
                                notEmpty: { message: 'Email address is required' },
                                regexp: {
                                    regexp: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
                                    message: 'Invalid email address'
                                }
                            }
                        },
                        password: {
                            validators: {
                                notEmpty: { message: 'Password is required' },
                                callback: {
                                    message: 'Please enter a stronger password',
                                    callback: function () {
                                        return validatePassword();
                                    }
                                }
                            }
                        },
                        password_confirmation: {
                            validators: {
                                notEmpty: { message: 'Password confirmation is required' },
                                identical: {
                                    compare: function () {
                                        return form.querySelector('[name="password"]').value;
                                    },
                                    message: 'Passwords do not match'
                                }
                            }
                        },
                        toc: {
                            validators: {
                                notEmpty: { message: 'You must accept the terms' }
                            }
                        }
                    },
                    plugins: {
                        trigger: new FormValidation.plugins.Trigger({
                            event: { password: false }
                        }),
                        bootstrap: new FormValidation.plugins.Bootstrap5({
                            rowSelector: '.fv-row',
                            eleInvalidClass: '',
                            eleValidClass: ''
                        })
                    }
                }
            );

            // ✅ SINGLE SUBMIT HANDLER
            form.addEventListener('submit', function (e) {
                e.preventDefault();
                e.stopImmediatePropagation();

                validator.revalidateField('password');

                validator.validate().then(function (status) {

                    if (status !== 'Valid') {
                        Swal.fire({
                            text: "Please fix the errors and try again.",
                            icon: "error",
                            buttonsStyling: false,
                            confirmButtonText: "Ok",
                            customClass: { confirmButton: "btn btn-primary" }
                        });
                        return;
                    }

                    if (submitButton.disabled) return; // extra safety

                    submitButton.setAttribute('data-kt-indicator', 'on');
                    submitButton.disabled = true;

                    axios.post(form.action, new FormData(form))
                        .then(function (response) {
                            Swal.fire({
                                text: response.data.message || 'Registration successful. Please verify your email.',
                                icon: "success",
                                buttonsStyling: false,
                                confirmButtonText: "Ok",
                                customClass: { confirmButton: "btn btn-primary" }
                            }).then(() => {
                                form.reset();
                                passwordMeter.reset();

                                const redirectUrl = form.dataset.ktRedirectUrl;
                                if (redirectUrl) {
                                    window.location.href = redirectUrl;
                                }
                            });
                        })
                        .catch(function (error) {
                            Swal.fire({
                                text: error.response?.data?.message || 'Something went wrong.',
                                icon: "error",
                                buttonsStyling: false,
                                confirmButtonText: "Ok",
                                customClass: { confirmButton: "btn btn-primary" }
                            });
                        })
                        .finally(function () {
                            submitButton.removeAttribute('data-kt-indicator');
                            submitButton.disabled = false;
                        });
                });
            }, { once: true });

            // Password live revalidation
            form.querySelector('[name="password"]').addEventListener('input', function () {
                validator.updateFieldStatus('password', 'NotValidated');
            });
        };

        return {
            init: function () {

                form = document.querySelector('#kt_sign_up_form');
                submitButton = document.querySelector('#kt_sign_up_submit');

                if (!form || !submitButton) return;

                passwordMeter = KTPasswordMeter.getInstance(
                    form.querySelector('[data-kt-password-meter="true"]')
                );

                handleFormAjax();
            }
        };
    }();

    KTUtil.onDOMContentLoaded(function () {
        KTSignupGeneral.init();
    });
}
